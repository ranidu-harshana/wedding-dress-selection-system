

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <?php echo implode('', $errors->all('<div>:message</div>')); ?>

<?php endif; ?>
    <div class="row">
        <div class="col-sm-7 col-6">
            <h4 class="page-title">Customer Profile</h4>
        </div>
    
        <div class="col-sm-5 col-6 text-right m-b-30 ">
            <?php if($customer->status == 1): ?>
                <form action="<?php echo e(route('cancel', $customer->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button class="btn btn-danger btn-rounded" type="submit"><i class="fas fa-ban"></i> Cancel</button>
                    <a href="<?php echo e(route('customer.edit', $customer->id)); ?>" class="btn btn-success btn-rounded"><i class="fas fa-edit"></i> Edit</a>
                    <a href="" class="btn btn-primary btn-rounded" data-toggle="modal" data-target="#postponedDateModal"><i class="fa fa-plus"></i> Postpone</a>
                </form>
            <?php else: ?>
                <form action="<?php echo e(route('re_schedule', $customer->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button class="btn btn-secondary btn-rounded" type="submit"><i class="far fa-calendar-alt"></i> Re-Schedule</button>
                    <a href="<?php echo e(route('customer.edit', $customer->id)); ?>" class="btn btn-success btn-rounded"><i class="fas fa-edit"></i> Edit</a>
                    <a href="" class="btn btn-primary btn-rounded" data-toggle="modal" data-target="#postponedDateModal"><i class="fa fa-plus"></i> Postpone</a>
                </form>
            <?php endif; ?>
            
            <div class="modal fade" id="postponedDateModal" tabindex="-1" role="dialog" aria-labelledby="postponedDateModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="postponedDateModalLabel">Postpone Date</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('postpone', $customer->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group">
                                    <input class="form-control" type="date" name="postpone_date" value="<?php echo e($customer->function_date); ?>" min="<?php echo e(date('Y-m-d')); ?>">
                                </div>
                        </div>
                        <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-success btn-sm" name="change_date">Change</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-box profile-header " id="profile-card">
        <div class="row">
            <div class="col-md-12">
                <div class="profile-view">
                    <div class="profile-img-wrap">
                        <div class="profile-img">
                            <a href="#"><img class="avatar" src="<?php echo e(asset('assets/img/user.jpg')); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="profile-basic">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="profile-info-left">
                                    <h3 class="user-name m-t-0 mb-0"><?php echo e($customer->name); ?></h3>
                                    <div class="staff-id">Bill Number : <?php echo e($customer->branch->prefix); ?><?php echo e($customer->bill_number); ?></div>
                                    <div class="staff-id">Booked On : <?php echo e($customer->created_at); ?></div>
                                    <div class="staff-id">Branch : <?php echo e($customer->branch->name); ?></div>
                                    
                                </div>
                            </div>
                            <div class="col-md-8">
                                <ul class="personal-info">
                                    <li>
                                        <span class="title">Phone 1</span>
                                        <span class="text"><a href="#"><?php echo e($customer->mobile_no1); ?></a></span>
                                    </li>

                                    <?php if($customer->mobile_no2 != NULL): ?>
                                        <li>
                                            <span class="title">Phone 2</span>
                                            <span class="text"><a href="#"><?php echo e($customer->mobile_no2); ?></a></span>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <li>
                                        <span class="title">Address</span>
                                        <span class="text"><?php echo e($customer->address); ?></span>
                                    </li>

                                    <?php if($customer->postponed == NULL): ?>
                                        <li>
                                            <span class="title">Function Date</span>
                                            <span class="text"><?php echo e($customer->function_date); ?></span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span class="title">Function Date</span>
                                            <span class="text"><?php echo e($customer->function_date); ?></span>
                                        </li>

                                        <li>
                                            <span class="title">Postponed From</span>
                                            <span class="text"><?php echo e($customer->postponed); ?></span>
                                        </li>
                                    <?php endif; ?>
                                    

                                    <li>
                                        <span class="title">Place</span>
                                        <span class="text"><?php echo e($customer->function_place); ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>                        
            </div>
        </div>
    </div>
    <div class="profile-tabs">
        <ul class="nav nav-tabs nav-tabs-bottom">
            <li class="nav-item" id="tab0"><a class="nav-link <?php if(session('tab0')): ?> active <?php endif; ?>" href="#measurement_tab" data-toggle="tab">Measurements</a></li>
            <li class="nav-item" id="tab1"><a class="nav-link <?php if(session('tab1')): ?> active <?php endif; ?>" href="#dress_selection_tab" data-toggle="tab">Dress Selection</a></li>
            <li class="nav-item" id="tab2"><a class="nav-link <?php if(session('tab2')): ?> active <?php endif; ?>" href="#bill_tab" data-toggle="tab">Bill</a></li>
            <li class="nav-item" id="tab3"><a class="nav-link <?php if(session('tab3')): ?> active <?php endif; ?>" href="#notes_tab" data-toggle="tab">Notes</a></li>
            <li class="nav-item" id="tab4"><a class="nav-link <?php if(session('tab4')): ?> active <?php endif; ?>" href="#other_tab" data-toggle="tab">Other</a></li>
            <?php if(auth()->check()): ?>
                <?php if(auth()->user()->is_admin()): ?>        
                    <li class="nav-item" id="tab5"><a class="nav-link <?php if(session('tab5')): ?> active <?php endif; ?>" href="#costs_tab" data-toggle="tab">Costs</a></li>
                <?php endif; ?>
            <?php endif; ?>
            </ul>

        <div class="tab-content">
            <div class="tab-pane <?php if(session('tab0')): ?> show active <?php endif; ?>" id="measurement_tab" >
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-box">
                            <h4 class="card-title">Enter Measurements</h4>
                            <table class="table table-hover ">
                                <thead>
                                    <tr>
                                        <th scope="col" style="width: 120px">POS</th>
                                        <th scope="col">Head</th>
                                        <th scope="col">Shoulder</th>
                                        <th scope="col">Chest</th>
                                        <th scope="col">Weist</th>
                                        <th scope="col">T.Length</th>
                                        <th scope="col">S.Size</th>
                                        <th scope="col">ARM</th>
                                        <th scope="col">J.Height</th>
                                        <th scope="col">Other</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $customer->measurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="col"><?php echo e($measurement->type); ?></td>
                                            <td scope="col">
                                                <?php if($measurement->head == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->head); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->shoulder == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->shoulder); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->chest == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->chest); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->weist == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->weist); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->tlength == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->tlength); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->ssize == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->ssize); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->arm == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->arm); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->jheight == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->jheight); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <?php if($measurement->other == NULL): ?>
                                                    0
                                                <?php else: ?>
                                                    <?php echo e($measurement->other); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="col">
                                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#editMeasurement<?php echo e($measurement->id); ?>">
                                                    Edit
                                                </button>
                                            </td>
                                        </tr>
                                        
                                        <div class="modal fade" id="editMeasurement<?php echo e($measurement->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editMeasurement<?php echo e($measurement->id); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="editMeasurement<?php echo e($measurement->id); ?>Label">Edit &nbsp;<span class="text-primary"><b><?php echo e($measurement->type); ?></b></span>&nbsp;&nbsp; Measurements</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('update_measurement', $measurement->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">Head</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" name="head" class="form-control" value="<?php if($measurement->head == NULL): ?>0 <?php else: ?> <?php echo e($measurement->head); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">Shoulder</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" name="shoulder" class="form-control" value="<?php if($measurement->shoulder == NULL): ?>0 <?php else: ?> <?php echo e($measurement->shoulder); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">Chest</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="chest" value="<?php if($measurement->chest == NULL): ?>0 <?php else: ?> <?php echo e($measurement->chest); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">Weist</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="weist" value="<?php if($measurement->weist == NULL): ?>0 <?php else: ?> <?php echo e($measurement->weist); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">T.Length</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="tlength" value="<?php if($measurement->tlength == NULL): ?>0 <?php else: ?> <?php echo e($measurement->tlength); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">S.Size</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="ssize" value="<?php if($measurement->ssize == NULL): ?>0 <?php else: ?> <?php echo e($measurement->ssize); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">Arm</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="arm" value="<?php if($measurement->arm == NULL): ?>0 <?php else: ?> <?php echo e($measurement->arm); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">J.Height</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="jheight" value="<?php if($measurement->jheight == NULL): ?>0 <?php else: ?> <?php echo e($measurement->jheight); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-md-3 col-form-label">Other</label>
                                                                <div class="col-md-9">
                                                                    <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="other" value="<?php if($measurement->other == NULL): ?>0 <?php else: ?> <?php echo e($measurement->other); ?> <?php endif; ?>">
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Save</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $measurement_list = []; ?>
                                    <?php $__currentLoopData = $customer->measurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php array_push($measurement_list, $measurement->type); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if(!in_array("GROOM", $measurement_list)): ?>
                                        <tr>
                                            <form action="<?php echo e(route('measurement.store')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <td>GROOM</td>
                                                <input type="hidden" name="type" value="GROOM">
                                                <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="head" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="shoulder" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="chest" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="weist" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="tlength" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="ssize" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="arm" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="jheight" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="text" onkeypress="return isNumberKey(event)" name="other" class="form-control">
                                                    </div>
                                                </th>
                                                <th scope="row">
                                                    <div class="form-group">
                                                        <input type="submit" name="submit" value="Save" id="" class="btn btn-primary btn-sm">
                                                    </div>
                                                </th>
                                            </form>
                                        </tr>
                                    <?php endif; ?>

                                    <?php for($i = 1; $i <= $customer->no_of_bestmen; $i++): ?>
                                        <?php if(!in_array("BESTMAN - ".$i, $measurement_list)): ?>
                                            <tr>
                                                <form action="<?php echo e(route('measurement.store')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="type" value="BESTMAN - <?php echo e($i); ?>">
                                                    <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                                    <td>BESTMAN - <?php echo e($i); ?></td>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="head" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="shoulder" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="chest" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="weist" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="tlength" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="ssize" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="arm" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="jheight" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="other" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="submit" name="submit" value="Save" id="" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </th>
                                                </form>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endfor; ?>

                                    <?php for($i = 0; $i < $customer->no_of_pageboys; $i++): ?>
                                        <?php if(!in_array("PAGEBOY - ".$i+1, $measurement_list)): ?>
                                            <tr>
                                                <form action="<?php echo e(route('measurement.store')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="type" value="PAGEBOY - <?php echo e($i+1); ?>">
                                                    <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                                    <td>PAGEBOY - <?php echo e($i+1); ?></td>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="head" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="shoulder" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="chest" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="weist" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="tlength" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="ssize" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="arm" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="jheight" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="text" onkeypress="return isNumberKey(event)" name="other" id="" class="form-control">
                                                        </div>
                                                    </th>
                                                    <th scope="row">
                                                        <div class="form-group">
                                                            <input type="submit" name="submit" value="Save" id="" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </th>
                                                </form>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane <?php if(session('tab1')): ?> active <?php endif; ?>" id="dress_selection_tab">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card-box">
                            <?php if($dress_selected_customer == NULL): ?>
                                <h4 class="card-title">Dress Selection Form</h4>
                                <form action="<?php echo e(route('dress.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($customer->id); ?>" name="customer_id">
                                    <div class="form-group row">
                                        <label class="col-form-label col-md-4">Groom's Jacket</label>
                                        <div class="col-md-8">
                                            <input name="groom_jacket" id="groom_jacket" type="text" class="form-control" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-form-label col-md-4">Groom's Cavani</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="groom_cavani" id="groom_cavani" autocomplete="off">
                                        </div>
                                    </div>
                                    <?php for($i = 0; $i < $customer->no_of_bestmen; $i++): ?>
                                        <div class="form-group row">
                                            <label class="col-form-label col-md-4">Bestman's Jacket - <?php echo e($i+1); ?></label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="bestman_jacket[]" id="bestman_jacket<?php echo e($i); ?>" autocomplete="off">
                                            </div>
                                        </div>
                                    <?php endfor; ?>

                                    <?php for($i = 0; $i < $customer->no_of_pageboys; $i++): ?>
                                        <div class="form-group row">
                                            <label class="col-form-label col-md-4">Pageboy's Jacket - <?php echo e($i+1); ?></label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="pageboy_jacket[]" id="pageboy_jacket<?php echo e($i); ?>" autocomplete="off">
                                            </div>
                                        </div>
                                    <?php endfor; ?>

                                    <div class="form-group row">
                                        <label class="col-form-label col-md-4">Group Cavani</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="group_cavani" id="group_cavani" autocomplete="off">
                                        </div>
                                    </div>

                                    <div class="text-right">
                                        <input type="submit" class="btn btn-primary " name="submit">
                                    </div>
                                </form>
                            <?php else: ?>
                                <h4 class="card-title">All Dress Selections</h4>
                                <div class="col-md-12">
                                    <table class="table">
                                        <?php $__currentLoopData = $dress_selected_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($dress->type); ?></td>
                                                <td><a href="" class="text"><?php echo e($dress->name); ?></a> </td>
                                                <td>
                                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#dressEdit<?php echo e($dress->id); ?>">
                                                        Edit
                                                    </button>
                                                </td>
                                            </tr>
                                            <div class="modal fade" id="dressEdit<?php echo e($dress->id); ?>" tabindex="-1" role="dialog" aria-labelledby="dressEdit<?php echo e($dress->id); ?>Label" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="dressEdit<?php echo e($dress->id); ?>Label">Edit &nbsp; <span class="text-primary"><?php echo e($dress->type); ?></span></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('dress.update', $dress->id)); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="form-group row">
                                                                    <label class="col-md-4 col-form-label"><?php echo e($dress->type); ?></label>
                                                                    <div class="col-md-8">
                                                                        <?php if($dress->type == "Groom's Jacket"): ?>
                                                                            <input type="text" name="dress" class="form-control" value="<?php echo e($dress->name); ?>" id="groom_jacket" autocomplete="off">
                                                                        <?php elseif($dress->type == "Groom's Cavani"): ?>
                                                                            <input type="text" name="dress" class="form-control" value="<?php echo e($dress->name); ?>" id="groom_cavani" autocomplete="off">
                                                                        <?php elseif($dress->type == "Group Cavani"): ?>
                                                                            <input type="text" name="dress" class="form-control" value="<?php echo e($dress->name); ?>" id="group_cavani" autocomplete="off">
                                                                        <?php else: ?>
                                                                            <?php for($i = 0; $i < 8; $i++): ?>
                                                                                <?php if($dress->type == "Bestman's Jacket - ".$i+1): ?>
                                                                                    <input type="text" name="dress" class="form-control" value="<?php echo e($dress->name); ?>" id="bestman_jacket<?php echo e($i); ?>" autocomplete="off">
                                                                                <?php elseif($dress->type == "Pageboy's Jacket - ".$i+1): ?>
                                                                                    <input type="text" name="dress" class="form-control" value="<?php echo e($dress->name); ?>" id="pageboy_jacket<?php echo e($i); ?>" autocomplete="off">
                                                                                <?php endif; ?>
                                                                            <?php endfor; ?>
                                                                        <?php endif; ?>
                                                                        
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">Save</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                                
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if($dress_selected_customer != NULL): ?>
                        <div class="col-lg-6" id="display_area" style="display: none">
                    <?php else: ?>
                        <div class="col-lg-6" id="display_area">
                    <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="tab-pane <?php if(session('tab2')): ?> active <?php endif; ?>" id="bill_tab" >
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card-box">
                            <h4 class="card-title">Billing</h4>
                            <ul class="personal-info">
                                <li>
                                    <span class="title">Total Amount</span>
                                    <span class="text-primary"> <?php echo e($customer->total_amount); ?>.00 </span>
                                </li>

                                <li>
                                    <span class="title">Discount </span>
                                    <span class="text-primary"> <?php echo e($customer->discount); ?>.00 </span>
                                </li>
                                
                                <li>
                                    <span class="title">Advance Payment </span>
                                    <span class="text-primary"> <?php echo e($customer->advance_payment); ?>.00 </span>
                                </li>
                                <?php $intering_payment = 0; ?>
                                <?php $__currentLoopData = $customer->intering_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $intering_payment += $value->intering_payment; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $balance = $customer->total_amount - ($customer->discount + $customer->advance_payment  + $intering_payment) ?>
                                <li>
                                    <span class="title">Balance </span>
                                    <span class="text"><a href="#">
                                        <?php if($balance == 0): ?>
                                            <span class="text-success">Payment Success</span> 
                                        <?php else: ?>
                                            <?php echo e($balance); ?>.00
                                        <?php endif; ?>
                                    </a></span>
                                </li>

                            </ul>
                            <?php if($balance != 0): ?>
                                <form action="<?php echo e(route('intering_payment.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        <label class="col-form-label col-md-4">Intering Payment</label>
                                        <div class="col-md-4">
                                            <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                            <input type="text" class="form-control" name="intering_payment">
                                        </div>
                                        <div class="col-md-2">
                                            <input type="submit" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <table class="table table-striped table-hover table-sm">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Intering Payment</th>
                                    <th scope="col">Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($customer->intering_payments) != 0): ?>
                                    <?php $counter = 1; ?>
                                    <?php $__currentLoopData = $customer->intering_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intering_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($counter); ?></th>
                                            <td><?php echo e($intering_payment->intering_payment); ?>.00</td>
                                            <td><?php echo e($intering_payment->created_at); ?></td>
                                        </tr>
                                        <?php $counter++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td scope="row" colspan="3" class="text-center text-secondary">No Any Payments</td>
                                    </tr>  
                                <?php endif; ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane <?php if(session('tab3')): ?> active <?php endif; ?>" id="notes_tab">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card-box">
                            <h3 class="card-title">Add Note</h3>
                            <div class="experience-box">
                                
                                <form action="<?php echo e(route('note.store')); ?>" method="post" style="display: block" id="note_create_form">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                    <div class="form-group">
                                        <label>Note</label>
                                        <textarea name="note" required class="form-control" id="" cols="30" rows="5"></textarea>
                                    </div>

                                    <div class="text-right">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>

                                
                                <form action="" method="post" style="display: none" id="note_edit_form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("PUT"); ?>
                                    <div class="form-group">
                                        <label>Edit Note</label>
                                        <textarea name="note" required class="form-control" id="edit_note" cols="30" rows="5"></textarea>
                                    </div>

                                    <div class="text-right">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                            <table class="table table-striped table-hover table-sm">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Note</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($note->status == 1): ?>
                                                    <input type="checkbox" checked>
                                                <?php else: ?>
                                                    <input type="checkbox">
                                                <?php endif; ?>
                                                
                                            </td>
                                            <td><?php echo e($note->note); ?></td>
                                            <td style="width: 110px"><?php echo e($note->created_at); ?></td>
                                            <td style="width: 100px">
                                                <div class="row">
                                                    <input type="hidden" value="<?php echo e($note->id); ?>" id="note_id<?php echo e($i); ?>">
                                                    <button type="submit" class="btn btn-warning btn-sm" name="edit" id="edit_btn<?php echo e($i); ?>"><i class="fal fa-edit"></i> </button>&nbsp;
                                                    <form action="<?php echo e(route('note.destroy', $note->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm" name="delete"><i class="far fa-trash-alt"></i> </button>&nbsp;
                                                    </form>
                                                    <form action="<?php echo e(route('note.mark_as_read', $note->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field("PUT"); ?>
                                                        <button type="submit" class="btn btn-success btn-sm" name="mark_as_done"><i class="fas fa-clipboard-check"></i> </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="" id="last_count_i" value="<?php echo e($i); ?>">
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane <?php if(session('tab4')): ?> active <?php endif; ?>" id="other_tab" >
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card-box">
                            <h4 class="card-title">Other Details</h4>
                            <ul class="personal-info">
                                <li>
                                    <span class="title">Dressing Place </span>
                                    <span class="text-primary">
                                        <?php if($customer->dressing_place == 1): ?>
                                            In Sri Kula Medura Branch
                                        <?php else: ?>
                                            In Home
                                        <?php endif; ?>    
                                    </span>
                                </li>

                                <li>
                                    <span class="title">Going Away Change</span>
                                    <span class="text-primary">
                                        <?php if($customer->going_away_change_place == NULL): ?>
                                            Yes
                                        <?php else: ?>
                                            <?php echo e($customer->going_away_change_place); ?>

                                        <?php endif; ?>
                                    </span>
                                </li>

                                <?php if($customer->photography_place != NULL): ?>
                                    <li>
                                        <span class="title">Photography Place</span>
                                        <span class="text-primary"> <?php echo e($customer->photography_place); ?> </span>
                                    </li>
                                <?php endif; ?>
                                
                                <?php if($customer->bridal_dressing_place != NULL): ?>
                                    <li>
                                        <span class="title">Bridal Styling Place </span>
                                        <span class="text-primary"> <?php echo e($customer->bridal_dressing_place); ?> </span>
                                    </li> 
                                <?php endif; ?>

                            </ul> <br>

                            <?php if($customer->bridal_color != NULL && $customer->sec_bridal_group_color != NULL): ?>
                                <ul class="personal-info">
                                    <h4 class="card-title">Colors of Jewlleries and Clothes</h4>
                                    
                                    <?php if($customer->bridal_color != NULL): ?>
                                        <li>
                                            <span class="title">Bride </span>
                                            <span class="text-primary"> <?php echo e($customer->bridal_color); ?> </span>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <?php if($customer->sec_bridal_group_color != NULL): ?>
                                        <li>
                                            <span class="title">second brides and group </span>
                                            <span class="text-primary"> <?php echo e($customer->sec_bridal_group_color); ?> </span>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php if(auth()->check()): ?>
                <?php if(auth()->user()->is_admin()): ?>
                    <div class="tab-pane <?php if(session('tab5')): ?> active <?php endif; ?>" id="costs_tab" >
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card-box">
                                    
                                    <?php if($customer->cost == NULL): ?>
                                        <h4 class="card-title">Enter Costs</h4>
                                        <form action="<?php echo e(route('cost.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="text" name="customer_id" hidden value="<?php echo e($customer->id); ?>">
                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Transport</label>
                                                <div class="col-md-8">
                                                    <input name="transport" id="transport" type="text" class="form-control" autocomplete="off">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Salary</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="salary" id="salary" autocomplete="off">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Cleaning</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="cleaning" id="cleaning" autocomplete="off">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Depriciation</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="depriciation" id="depriciation" autocomplete="off">
                                                </div>
                                            </div>

                                            <div class="text-right">
                                                <input type="submit" class="btn btn-primary " name="submit">
                                            </div>
                                        </form>
                                    <?php else: ?>
                                        <h4 class="card-title">Edit Costs</h4>
                                        <form action="<?php echo e(route('cost.update', $customer->cost->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="text" name="customer_id" hidden value="<?php echo e($customer->id); ?>">
                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Transport</label>
                                                <div class="col-md-8">
                                                    <input name="transport" id="transport" type="text" class="form-control" autocomplete="off" value="<?php echo e($customer->cost->transport); ?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Salary</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="salary" id="salary" autocomplete="off" value="<?php echo e($customer->cost->salary); ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Cleaning</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="cleaning" id="cleaning" autocomplete="off" value="<?php echo e($customer->cost->cleaning); ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-form-label col-md-4">Depriciation</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="depriciation" id="depriciation" autocomplete="off" value="<?php echo e($customer->cost->depriciation); ?>">
                                                </div>
                                            </div>

                                            <div class="text-right">
                                                <input type="submit" class="btn btn-primary " name="submit">
                                            </div>
                                        </form>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>        
        </div>
    </div>

    
    <script>
        
        var path = "<?php echo e(route('autocomplete_groom_jacket')); ?>";
        $('#groom_jacket').typeahead({
            minLength: 2,
            source:  function (query, process) {
                return $.get(path, { term: query }, function (data) {
                    return process(data);
                });
            },
            afterSelect: function (item) {
                $.ajax({
                    url: "../item/"+item,
                    type: "GET",
                    success: function(data){
                        image_url = "<?php echo e(asset('storage/item/')); ?>"
                        image_url += '/'
                        image_url += data.image
                        $('#display_area').html("<img src='" + image_url + "' class='rounded mx-auto d-block img-thumbnail'>")
                    }
                })
            }
        });

        var path1 = "<?php echo e(route('autocomplete_groom_cavani')); ?>";
        $('#groom_cavani').typeahead({
            minLength: 2,
            source:  function (query1, process1) {
                return $.get(path1, { term1: query1 }, function (data1) {
                    return process1(data1);
                });
            },
            afterSelect: function (item) {
                $.ajax({
                    url: "../item/"+item,
                    type: "GET",
                    success: function(data){
                        image_url = "<?php echo e(asset('storage/item/')); ?>"
                        image_url += '/'
                        image_url += data.image
                        $('#display_area').html("<img src='" + image_url + "' class='rounded mx-auto d-block img-thumbnail'>")
                    }
                })
            }
        });

        for (let index = 0; index < 5; index++) {
            var path2 = "<?php echo e(route('autocomplete_bestman_jacket')); ?>";
            $('#bestman_jacket'+index).typeahead({
                minLength: 2,
                source:  function (query2, process2) {
                    return $.get(path2, { term2: query2 }, function (data2) {
                        return process2(data2);
                    });
                },
                afterSelect: function (item) {
                    $.ajax({
                        url: "../item/"+item,
                        type: "GET",
                        success: function(data){
                            image_url = "<?php echo e(asset('storage/item/')); ?>"
                            image_url += '/'
                            image_url += data.image
                            $('#display_area').html("<img src='" + image_url + "' class='rounded mx-auto d-block img-thumbnail'>")
                        }
                    })
                }
            });
        }
        
        for (let index = 0; index < 5; index++) {
            var path3 = "<?php echo e(route('autocomplete_pageboy_jacket')); ?>";
            $('#pageboy_jacket'+index).typeahead({
                minLength: 2,
                source:  function (query3, process3) {
                    return $.get(path3, { term3: query3 }, function (data3) {
                        return process3(data3);
                    });
                },
                afterSelect: function (item) {
                    $.ajax({
                        url: "../item/"+item,
                        type: "GET",
                        success: function(data){
                            image_url = "<?php echo e(asset('storage/item/')); ?>"
                            image_url += '/'
                            image_url += data.image
                            $('#display_area').html("<img src='" + image_url + "' class='rounded mx-auto d-block img-thumbnail'>")
                        }
                    })
                }
            });
        }

        var path4 = "<?php echo e(route('autocomplete_group_cavani')); ?>";
        $('#group_cavani').typeahead({
            minLength: 2,
            source:  function (query4, process4) {
                return $.get(path4, { term4: query4 }, function (data4) {
                    return process4(data4);
                });
            },
            afterSelect: function (item) {
                $.ajax({
                    url: "../item/"+item,
                    type: "GET",
                    success: function(data){
                        image_url = "<?php echo e(asset('storage/item/')); ?>"
                        image_url += '/'
                        image_url += data.image
                        $('#display_area').html("<img src='" + image_url + "' class='rounded mx-auto d-block img-thumbnail'>")
                    }
                })
            }
        });
    </script>
<?php $__env->stopSection(); ?>     
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/customer-profile.blade.php ENDPATH**/ ?>