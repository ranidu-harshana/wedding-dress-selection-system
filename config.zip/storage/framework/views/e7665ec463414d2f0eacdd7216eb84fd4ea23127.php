

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="card-box">
                <h4 class="card-title">Schedule</h4>

                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('customer.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label>Bill Number</label>
                        <input name="bill_number" value="<?php echo e(old('bill_number')); ?>" type="text" required class="form-control <?php $__errorArgs = ['bill_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off">
                        <?php $__errorArgs = ['bill_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Branch</label>
                        <select name="branch_id" required class="form-control" value="<?php echo e(old('branch_id')); ?>">
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" value="<?php echo e(old('name')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Address</label>
                        <input name="address" value="<?php echo e(old('address')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>Mobile No. 1</label>
                        <input name="mobile_no1" value="<?php echo e(old('mobile_no1')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>Mobile No. 2</label>
                        <input name="mobile_no2" value="<?php echo e(old('mobile_no2')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Function Date</label>
                        <input name="function_date" value="<?php echo e(old('function_date')); ?>" type="date" required class="form-control <?php $__errorArgs = ['function_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" min="<?php echo e(date('Y-m-d')); ?>">
                        <?php $__errorArgs = ['function_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Function Place</label>
                        <input name="function_place" id="function_place" value="<?php echo e(old('function_place')); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Number of Bestmen</label>
                        <select name="no_of_bestmen" id="" required class="form-control">
                            <option value="0">Select</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Number of Pageboys</label>
                        <select name="no_of_pageboys" id="" required class="form-control">
                            <option value="0">Select</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Will you dress in our place?</label>
                        <select name="dressing_place" value="<?php echo e(old('dressing_place')); ?>" id="" required class="form-control">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Going away Change? </label>
                        <select name="" id="going_away_change_place" required onchange="visibleTextField()">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>
                    
                    <div class="form-group" style="display: none" id="going_away_textfield">
                        <label>Dress Changing Place</label>
                        <input name="going_away_change_place" value="<?php echo e(old('going_away_change_place')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>
                    

                    <div class="form-group">
                        <label>Bridal Saloon </label>
                        <input name="bridal_dressing_place" value="<?php echo e(old('bridal_dressing_place')); ?>" id="bridal_dressing_place" type="text"  class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Bridal Color (Saree)</label>
                        <input name="bridal_color" value="<?php echo e(old('bridal_color')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Bride Mates color</label>
                        <input name="sec_bridal_group_color" value="<?php echo e(old('sec_bridal_group_color')); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Photographer/Studio</label>
                        <input name="photography_place" value="<?php echo e(old('photography_place')); ?>" id="photography_place" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Total Amount</label>
                        <input name="total_amount" id="total_amount" value="<?php echo e(old('total_amount')); ?>" type="number" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Discount</label>
                        <input name="discount" id="discount" value="<?php echo e(old('discount')); ?>" type="number" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Advance Payment</label>
                        <input name="advance_payment" id="advance_payment" value="<?php echo e(old('advance_payment')); ?>" type="number" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Balance to be paid</label>
                        <input name="balance_to_be_paid" id="balance_to_be_paid" type="number" class="form-control" disabled>
                    </div>

                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        
    </div>

    <script>
        var path0 = "<?php echo e(route('autocomplete_function_place')); ?>";
        $('#function_place').typeahead({
            
            source:  function (query0, process0) {
                return $.get(path0, { term0: query0 }, function (data0) {
                    return process0(data0);
                });
            }
        });

        var path = "<?php echo e(route('autocomplete_brida_place')); ?>";
        $('#bridal_dressing_place').typeahead({
            
            source:  function (query, process) {
                return $.get(path, { term: query }, function (data) {
                    return process(data);
                });
            }
        });

        var path1 = "<?php echo e(route('autocomplete_photography_place')); ?>";
        $('#photography_place').typeahead({
            
            source:  function (query1, process1) {
                return $.get(path1, { term1: query1 }, function (data1) {
                    return process1(data1);
                });
            }
        });

        $('#total_amount').keyup(function(){
            var total_amount = $('#total_amount').val()
            var discount = $('#discount').val()
            var advance_payment = $('#advance_payment').val()
            
            var balance_to_be_paid = Number(total_amount)-(Number(discount)+Number(advance_payment));
            $('#balance_to_be_paid').val(balance_to_be_paid);
        });

        $('#discount').keyup(function(){
            var total_amount = $('#total_amount').val()
            var discount = $('#discount').val()
            var advance_payment = $('#advance_payment').val()
            
            var balance_to_be_paid = Number(total_amount)-(Number(discount)+Number(advance_payment));
            $('#balance_to_be_paid').val(balance_to_be_paid);
        });

        $('#advance_payment').keyup(function(){
            var total_amount = $('#total_amount').val()
            var discount = $('#discount').val()
            var advance_payment = $('#advance_payment').val()

            var balance_to_be_paid = Number(total_amount)-(Number(discount)+Number(advance_payment));
            $('#balance_to_be_paid').val(balance_to_be_paid);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/create-bill.blade.php ENDPATH**/ ?>