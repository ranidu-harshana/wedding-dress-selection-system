

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card-box">
                <h4 class="card-title">Create Item Category</h4>
                <?php if(session('item-category-created')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('item-category-created')); ?>

                    </div>
                <?php elseif(session('item-category-updated')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('item-category-updated')); ?>

                    </div>
                <?php elseif(session('item-category-deleted')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('item-category-deleted')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($category)): ?>
                    <form action="<?php echo e(route('item_category.update', $category->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label>Category Name</label>
                            <input type="text" name="cat_name" class="form-control" value="<?php echo e($category->cat_name); ?>">
                            <span class="text-danger small">*Do not change sequence of Item Categories when editing</span>
                        </div>
                    
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('item_category.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Category Name</label>
                            <input type="text" name="cat_name" class="form-control">
                        </div>
                    
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>

                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card-box">
                <div class="card-block">
                    <h5 class="text-bold card-title">Striped Rows</h5>
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Edit</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->cat_name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('item_category.edit', $category->id)); ?>">
                                                <button class="btn btn-primary btn-sm">Edit</button>
                                            </a>
                                        </td>
                                        
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/create-item-category.blade.php ENDPATH**/ ?>