

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-block">
                    <h6 class="card-title text-bold">All Reserved Items</h6>
                    
                    <div class="table-responsive">
                        <table id="all_reserved_items_datatable" class="table table-striped table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>Reserved Date</th>
                                    <th>Item</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($dress->name != NULL): ?>
                                        <tr>
                                            <td><?php echo e($dress->customer->function_date); ?></td>
                                            <td><?php echo e($dress->name); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Reserved Date</th>
                                    <th>Item</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/view-all-reserved-items.blade.php ENDPATH**/ ?>