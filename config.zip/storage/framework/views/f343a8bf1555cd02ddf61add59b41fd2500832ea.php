<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <div class="container-fluid">
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border border-dark rounded p-2">
                <p>Date: <?php echo e($customer->function_date); ?></p>
                <table style="width: 100%">
                    <tr>
                        <td>Bill No: <?php echo e($customer->branch->prefix); ?><?php echo e($customer->bill_number); ?></td>
                        <td class="text-right">Name: <?php echo e($customer->name); ?></td>
                        <td class="text-right">Function Place: <?php echo e($customer->function_place); ?></td>
                    </tr>

                    <tr>
                        <td>Dressing Type: <?php if($customer->dressing_place == 1): ?> In <?php else: ?> Out <?php endif; ?></td>
                        <td  colspan="2">Going Away Change: <?php if($customer->going_away_change_place == NULL): ?> Yes <?php else: ?> <?php echo e($customer->going_away_change_place); ?> <?php endif; ?></td>
                    </tr>

                    <tr>
                        <td>No of BestMen: <?php echo e($customer->no_of_bestmen); ?></td>
                        <td  colspan="2">No of PageBoys: <?php echo e($customer->no_of_pageboys); ?></td>
                    </tr>
                </table>
                <hr>
                <div>
                    <table style="width: 35%" >
                        <?php $__currentLoopData = $customer->dress_selections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dress_selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dress_selection->type); ?></td>
                                <td><?php echo e($dress_selection->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <hr>
                <div>
                    <ul>Notes:
                        <?php $__currentLoopData = $customer->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='font-size: 12px; font-family:Consolas, "Andale Mono WT", "Andale Mono", "Lucida Console", "Lucida Sans Typewriter", "DejaVu Sans Mono", "Bitstream Vera Sans Mono", "Liberation Mono", "Nimbus Mono L", Monaco, "Courier New", Courier, monospace;'><?php echo e($note->note); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/reservations-pdf-view.blade.php ENDPATH**/ ?>