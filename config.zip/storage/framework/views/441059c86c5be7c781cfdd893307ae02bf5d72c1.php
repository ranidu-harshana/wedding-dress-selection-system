

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card-box">
                <h4 class="card-title">Create Branch</h4>
                <?php if(session('branch-created')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('branch-created')); ?>

                    </div>
                <?php elseif(session('branch-updated')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('branch-updated')); ?>

                    </div>
                <?php elseif(session('branch-deleted')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('branch-deleted')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($branch)): ?>
                    <form action="<?php echo e(route('branch.update', $branch->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label>Branch Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($branch->name); ?>" autocomplete="off">
                        </div>

                        <div class="form-group">
                            <label>Prefix</label>
                            <input type="text" name="prefix" class="form-control" value="<?php echo e($branch->prefix); ?>" autocomplete="off">
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('branch.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Branch Name</label>
                            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Prefix</label>
                            <input type="text" name="prefix" class="form-control <?php $__errorArgs = ['prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card-box">
                <div class="card-block">
                    <h5 class="text-bold card-title">Striped Rows</h5>
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($branch->id); ?></td>
                                        <td><?php echo e($branch->name); ?></td>
                                        <td><?php echo e($branch->prefix); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('branch.edit', $branch->id)); ?>">
                                                <button class="btn btn-primary btn-sm">Edit</button>
                                            </a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('branch.destroy', $branch->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/create-branch.blade.php ENDPATH**/ ?>