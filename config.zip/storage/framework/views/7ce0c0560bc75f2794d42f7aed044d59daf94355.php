

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="card-box">
                <h4 class="card-title">Schedule</h4>

                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('customer.update', $customer->id )); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                        <label>Bill Number</label>
                        <input name="bill_number" disabled value="<?php echo e($customer->bill_number); ?>" type="text" required class="form-control <?php $__errorArgs = ['bill_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" >
                        <?php $__errorArgs = ['bill_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Branch</label>
                        <select name="branch_id" required class="form-control" value="<?php echo e($customer->branch_id); ?>">
                            <option value="<?php echo e($customer->branch->id); ?>"><?php echo e($customer->branch->name); ?></option>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($customer->branch->name != $branch->name ): ?>
                                    <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" value="<?php echo e($customer->name); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Address</label>
                        <input name="address" value="<?php echo e($customer->address); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>Mobile No. 1</label>
                        <input name="mobile_no1" value="<?php echo e($customer->mobile_no1); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>Mobile No. 2</label>
                        <input name="mobile_no2" value="<?php echo e($customer->mobile_no2); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Function Date</label>
                        <input name="function_date" value="<?php echo e($customer->function_date); ?>" type="date" required class="form-control <?php $__errorArgs = ['function_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" min="<?php echo e(date('Y-m-d')); ?>">
                        <?php $__errorArgs = ['function_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Function Place</label>
                        <input name="function_place" value="<?php echo e($customer->function_place); ?>" type="text" required class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Number of Bestmen</label>
                        <select name="no_of_bestmen" id="" required class="form-control">
                            <option value="<?php echo e($customer->no_of_bestmen); ?>"><?php echo e($customer->no_of_bestmen); ?></option>
                            <?php for($i = 1; $i < 9; $i++): ?>
                                <?php if($customer->no_of_bestmen != $i): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Number of Pageboys</label>
                        <select name="no_of_pageboys" id="" required class="form-control">
                            <option value="<?php echo e($customer->no_of_pageboys); ?>"><?php echo e($customer->no_of_pageboys); ?></option>
                            <?php for($i = 1; $i < 9; $i++): ?>
                                <?php if($customer->no_of_pageboys != $i): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Will you dress in our place?</label>
                        <select name="dressing_place" value="<?php echo e($customer->dressing_place); ?>" id="" required class="form-control">
                            <?php if($customer->dressing_place == 1): ?>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            <?php else: ?>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <?php if($customer->going_away_change_place == NULL): ?>
                        <div class="form-group">
                            <label>Going away Change? </label>
                            <select name="" id="going_away_change_place" required onchange="visibleTextField()">
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="display: none" id="going_away_textfield">
                            <label>Dress Changing Place</label>
                            <input name="going_away_change_place" value="<?php echo e(old('going_away_change_place')); ?>" type="text" class="form-control" autocomplete="off">
                        </div>
                        
                    <?php else: ?>
                        <div class="form-group">
                            <label>Dress Changing Place (Going Away - NO)</label>
                            <input name="going_away_change_place" value="<?php echo e($customer->going_away_change_place); ?>" type="text" class="form-control" autocomplete="off">
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label>Bridal Saloon </label>
                        <input name="bridal_dressing_place" value="<?php echo e($customer->bridal_dressing_place); ?>" id="bridal_dressing_place" type="text"  class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Bridal Color (Saree)</label>
                        <input name="bridal_color" value="<?php echo e($customer->bridal_color); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Bride Mates color</label>
                        <input name="sec_bridal_group_color" value="<?php echo e($customer->sec_bridal_group_color); ?>" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Photographer Studio</label>
                        <input name="photography_place" value="<?php echo e($customer->photography_place); ?>" id="photography_place" type="text" class="form-control" autocomplete="off">
                    </div>

                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        
    </div>

    <script>
        var path = "<?php echo e(route('autocomplete_brida_place')); ?>";
        $('#bridal_dressing_place').typeahead({
            
            source:  function (query, process) {
                return $.get(path, { term: query }, function (data) {
                    return process(data);
                });
            }
        });

        var path1 = "<?php echo e(route('autocomplete_photography_place')); ?>";
        $('#photography_place').typeahead({
            
            source:  function (query1, process1) {
                return $.get(path1, { term1: query1 }, function (data1) {
                    return process1(data1);
                });
            }
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/edit-bill.blade.php ENDPATH**/ ?>