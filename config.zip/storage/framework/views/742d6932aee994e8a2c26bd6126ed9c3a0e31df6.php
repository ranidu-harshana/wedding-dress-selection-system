

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card-box">
                <h4 class="card-title">Create Item</h4>
                
                <form action="<?php echo e(route('item.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label>Item Category</label>
                        <select name="item_category_id" id="" class="form-control" required>
                            <option value="<?php echo e($item->item_category_id); ?>"><?php echo e($item->item_category->cat_name); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->item_category->cat_name != $category->cat_name): ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->cat_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Item Code</label>
                        <input name="item_code" type="text" required class="form-control <?php $__errorArgs = ['item_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($item->item_code); ?>" autocomplete="off">
                        <?php $__errorArgs = ['item_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Item Description</label>
                        <input name="item_desc" type="text" value="<?php echo e($item->item_desc); ?>" required class="form-control <?php $__errorArgs = ['item_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Item Type</label>
                        <select name="item_type" id="" class="form-control" required>
                            <?php if($item->item_type == "Bestman"): ?>
                                <option value="Bestman">Bestman</option>
                                <option value="Groom">Groom</option>
                                <option value="Pageboy">Pageboy</option>
                            <?php elseif($item->item_type == "Groom"): ?>
                                <option value="Groom">Groom</option>
                                <option value="Bestman">Bestman</option>
                                <option value="Pageboy">Pageboy</option>
                            <?php else: ?>
                                <option value="Pageboy">Pageboy</option>
                                <option value="Bestman">Bestman</option>
                                <option value="Groom">Groom</option>
                            <?php endif; ?>
                            
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Item Image</label>
                        <input name="item_image_url" type="file"  class="form-control">
                        <?php $__errorArgs = ['item_image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                        <div class="col-md-3 col-sm-3 col-4 col-lg-3 col-xl-2">
                            <div class="product-thumbnail">
                            
                                <img src="<?php echo e(asset('storage/item/'.$item->item_image_url)); ?>" class="img-thumbnail img-fluid" alt="">
                                <span class="product-remove" title="remove"><i class="fa fa-close"></i></span>
                            </div>
                        </div>

                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-6">
            <img src="<?php echo e(asset('storage/item/'.$item->item_image_url)); ?>" alt="" class="image-responsive" width="100%">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/edit-item.blade.php ENDPATH**/ ?>