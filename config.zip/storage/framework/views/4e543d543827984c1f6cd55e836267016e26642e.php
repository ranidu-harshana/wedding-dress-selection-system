<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table class="table table-sm table-bordered table-striped">
        <thead>
            <tr>
                <th scope="col">Bill No</th>
                <th scope="col">Name</th>
                <th scope="col">Total Bill</th>
                <th scope="col">Transport</th>
                <th scope="col">Salary</th>
                <th scope="col">Cleaning</th>
                <th scope="col">Depriciation</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $tot_total_amount = 0;
                $tot_transport = 0;
                $tot_salary = 0;
                $tot_cleaning = 0;
                $tot_depriciation = 0;
            ?>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($customer->branch->prefix); ?><?php echo e($customer->bill_number); ?></th>
                    <td><?php echo e($customer->name); ?></td>
                    <td class="text-right"><?php echo e($customer->total_amount); ?></td>
                    <td class="text-right"><?php if($customer->cost != NULL): ?> <?php echo e($customer->cost->transport); ?> <?php else: ?> 0 <?php endif; ?> </td>
                    <td class="text-right"><?php if($customer->cost != NULL): ?> <?php echo e($customer->cost->salary); ?> <?php else: ?> 0 <?php endif; ?> </td>
                    <td class="text-right"><?php if($customer->cost != NULL): ?> <?php echo e($customer->cost->cleaning); ?> <?php else: ?> 0 <?php endif; ?> </td>
                    <td class="text-right"><?php if($customer->cost != NULL): ?> <?php echo e($customer->cost->depriciation); ?> <?php else: ?> 0 <?php endif; ?> </td>
                </tr>
                <?php
                    $tot_total_amount += $customer->total_amount;
                    if ($customer->cost != NULL) {
                        $tot_transport += $customer->cost->transport;
                        $tot_salary += $customer->cost->salary;
                        $tot_cleaning += $customer->cost->cleaning;
                        $tot_depriciation += $customer->cost->depriciation;
                    }
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <th scope="row" colspan="2" class="text-center">Total</th>
                <td class="text-right"><?php echo e($tot_total_amount); ?></td>
                <td class="text-right"><?php echo e($tot_transport); ?></td>
                <td class="text-right"><?php echo e($tot_salary); ?></td>
                <td class="text-right"><?php echo e($tot_cleaning); ?></td>
                <td class="text-right"><?php echo e($tot_depriciation); ?></td>
            </tr>

            <tr>
                <th scope="row" colspan="2" class="text-center">Net Income</th>
                <td class="text-center" colspan="5"><?php echo e($tot_total_amount - ($tot_transport+$tot_salary+$tot_cleaning+$tot_depriciation)); ?></td>
            </tr>
        </tbody>
    </table>
</body>
</html><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/cost-report-pdf.blade.php ENDPATH**/ ?>