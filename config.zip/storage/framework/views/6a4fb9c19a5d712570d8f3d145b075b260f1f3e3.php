<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">Main</li>
                <li class="active">
                    <a href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('customer.create')); ?>"><i class="fas fa-clipboard-list"></i> <span>Create New</span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('customer.index')); ?>"><i class="fas fa-users"></i> <span>Events List</span></a>
                </li>

                <?php if(auth()->check()): ?>
                    <?php if(auth()->user()->is_admin()): ?>
                        <li class="submenu">
                            <a href="#"><i class="fa fa-user"></i> <span> Master </span> <span><i class="fas fa-caret-down"></i></span></a>
                            <ul style="display: none;">
                                <li><a href="<?php echo e(route('item_category.index')); ?>">Item Category</a></li>
                                <li><a href="<?php echo e(route('item.create')); ?>">Create Item</a></li>
                                <li><a href="<?php echo e(route('branch.index')); ?>">Branch</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(route('item.index')); ?>"><i class="fas fa-warehouse"></i> <span>Inventory</span></a>
                </li>

                <?php if(auth()->check()): ?>
                    <?php if(auth()->user()->is_admin()): ?>
                        <li>
                            <a href="<?php echo e(route('register')); ?>"><i class="fas fa-user"></i> <span>Create User</span></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <li class="submenu">
                    <a href="#"><i class="fas fa-book"></i> <span> Reports </span> <span><i class="fas fa-caret-down"></i></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(route('wedding.reservations.report.show')); ?>">Wedding Reservation</a></li>
                        <li><a href="<?php echo e(route('dress.index')); ?>">Reserved Items</a></li>
                        <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->is_admin()): ?>
                                <li><a href="<?php echo e(route('wedding.reservations.report.show.finance')); ?>">Account Summary</a></li>
                                <li><a href="<?php echo e(route('show_cost_report_pdf')); ?>">Cost Summary</a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/components/admin/admin-side-bar.blade.php ENDPATH**/ ?>