

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-block">
                    <h6 class="card-title text-bold">All Customers</h6>
                    <?php if(session('bill-created')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('bill-created')); ?>

                        </div>
                    <?php elseif(session('function-posponed')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('function-posponed')); ?>

                        </div>
                    <?php elseif(session('measurment-date-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('measurment-date-updated')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Bill Number</th>
                                    <th>Branch</th>
                                    <th>Name</th>
                                    <th>Function Date</th>
                                    <th>Measurement Date</th>
                                    <th>Edit Measurement Date</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($customer->branch->prefix); ?><?php echo e($customer->bill_number); ?></td>
                                        <td><?php echo e($customer->branch->name); ?></td>
                                        <td><?php echo e($customer->name); ?></td>
                                        <td><?php echo e($customer->function_date); ?></td>
                                        <td>
                                            <?php if($customer->measurement_date == NULL): ?>
                                                <p class="text-danger font-weight-bold">Enter a Date</p> 
                                            <?php else: ?>
                                                <?php echo e($customer->measurement_date); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal<?php echo e($customer->id); ?>">
                                                Edit
                                            </button>

                                            <div class="modal fade" id="exampleModal<?php echo e($customer->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Edit Measurement Date</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('edit_measurment_date', $customer->id)); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="form-group">
                                                                    <input class="form-control" type="date" name="measurement_date" value="<?php echo e($customer->measurement_date); ?>" min="<?php echo e(date('Y-m-d')); ?>">
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-success btn-sm" name="change_date">Change</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('customer.show', $customer->id)); ?>"><button class="btn btn-primary btn-sm">View</button></a>
                                        </td>
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Bill Number</th>
                                    <th>Branch</th>
                                    <th>Name</th>
                                    <th>Function Date</th>
                                    <th>Measurement Date</th>
                                    <th>Edit Measurement Date</th>
                                    <th>View</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/all-customers.blade.php ENDPATH**/ ?>