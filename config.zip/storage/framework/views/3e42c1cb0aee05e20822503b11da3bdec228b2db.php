

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-block">
                    <h6 class="card-title text-bold">Inventory</h6>
                    <?php if(session('item-created')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('item-created')); ?>

                        </div>
                    <?php elseif(session('item-updated')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('item-updated')); ?>

                        </div>
                    <?php elseif(session('item-deleted')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('item-deleted')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="table-responsive">
                        <table id="all_items_datatable" class="table table-striped table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Item Description</th>
                                    <th>Item Category</th>
                                    <th>Item Type</th>
                                    <?php if(auth()->check()): ?>
                                        <?php if(auth()->user()->is_admin()): ?>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->item_code); ?></td>
                                        <td><?php echo e($item->item_desc); ?></td>
                                        <td><?php echo e($item->item_category->cat_name); ?></td>
                                        <td><?php echo e($item->item_type); ?></td>
                                        <?php if(auth()->check()): ?>
                                            <?php if(auth()->user()->is_admin()): ?>
                                            <td>
                                                <a href="<?php echo e(route('item.edit', $item->id)); ?>">
                                                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">
                                                        Edit
                                                    </button>
                                                </a>
                                            </td>
                                            
                                            <td>
                                                <form action="<?php echo e(route('item.destroy', $item->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Item Description</th>
                                    <th>Item Category</th>
                                    <th>Item Type</th>
                                    <?php if(auth()->check()): ?>
                                        <?php if(auth()->user()->is_admin()): ?>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WORKS\Projects\Laraval\wedding_dress_reserving_system\resources\views/admin/view-all-items.blade.php ENDPATH**/ ?>